﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CP_02.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TB_GENERO",
                columns: table => new
                {
                    IdGenero = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    NomeGenero = table.Column<string>(type: "NVARCHAR2(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_GENERO", x => x.IdGenero);
                });

            migrationBuilder.CreateTable(
                name: "TB_USUARIO",
                columns: table => new
                {
                    IdUsuario = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    NomeUsuario = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    SobrenomeUsuario = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    DsEmail = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    DsSenha = table.Column<string>(type: "NVARCHAR2(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_USUARIO", x => x.IdUsuario);
                });

            migrationBuilder.CreateTable(
                name: "TB_FILME",
                columns: table => new
                {
                    IdFilme = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    Titulo = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    Diretor = table.Column<string>(type: "NVARCHAR2(30)", maxLength: 30, nullable: false),
                    DtLancamento = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: true),
                    ImgFilme = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    GeneroIdGenero = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Duracao = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    Classificacao = table.Column<string>(type: "NVARCHAR2(20)", maxLength: 20, nullable: false),
                    Sinopse = table.Column<string>(type: "NVARCHAR2(300)", maxLength: 300, nullable: false),
                    Status = table.Column<string>(type: "NVARCHAR2(15)", maxLength: 15, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_FILME", x => x.IdFilme);
                    table.ForeignKey(
                        name: "FK_TB_FILME_TB_GENERO_GeneroIdGenero",
                        column: x => x.GeneroIdGenero,
                        principalTable: "TB_GENERO",
                        principalColumn: "IdGenero",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_PERFIL",
                columns: table => new
                {
                    IdPerfil = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    UsuarioIdUsuario = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Imagem = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    Biografia = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    UsuarioId = table.Column<int>(type: "NUMBER(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_PERFIL", x => x.IdPerfil);
                    table.ForeignKey(
                        name: "FK_TB_PERFIL_TB_USUARIO_UsuarioId",
                        column: x => x.UsuarioId,
                        principalTable: "TB_USUARIO",
                        principalColumn: "IdUsuario",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TB_REVIEW",
                columns: table => new
                {
                    IdReview = table.Column<int>(type: "NUMBER(10)", nullable: false)
                        .Annotation("Oracle:Identity", "START WITH 1 INCREMENT BY 1"),
                    UsuarioIdUsuario = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    FilmeIdFilme = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Avaliacao = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    Comentario = table.Column<string>(type: "NVARCHAR2(100)", maxLength: 100, nullable: false),
                    DtReview = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: false),
                    FilmeId = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    UsuarioId = table.Column<int>(type: "NUMBER(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TB_REVIEW", x => x.IdReview);
                    table.ForeignKey(
                        name: "FK_TB_REVIEW_TB_FILME_FilmeId",
                        column: x => x.FilmeId,
                        principalTable: "TB_FILME",
                        principalColumn: "IdFilme",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TB_REVIEW_TB_USUARIO_UsuarioId",
                        column: x => x.UsuarioId,
                        principalTable: "TB_USUARIO",
                        principalColumn: "IdUsuario",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TB_FILME_GeneroIdGenero",
                table: "TB_FILME",
                column: "GeneroIdGenero");

            migrationBuilder.CreateIndex(
                name: "IX_TB_PERFIL_UsuarioId",
                table: "TB_PERFIL",
                column: "UsuarioId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TB_REVIEW_FilmeId",
                table: "TB_REVIEW",
                column: "FilmeId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_REVIEW_UsuarioId",
                table: "TB_REVIEW",
                column: "UsuarioId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TB_PERFIL");

            migrationBuilder.DropTable(
                name: "TB_REVIEW");

            migrationBuilder.DropTable(
                name: "TB_FILME");

            migrationBuilder.DropTable(
                name: "TB_USUARIO");

            migrationBuilder.DropTable(
                name: "TB_GENERO");
        }
    }
}
