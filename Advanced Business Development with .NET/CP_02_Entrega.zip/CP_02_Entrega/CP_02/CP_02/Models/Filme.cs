﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CP_02.Models
{
    [Table("TB_FILME")]

    public class Filme
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdFilme { get; set; }

        [Required(ErrorMessage = "O título do filme é obrigatório.")]
        [StringLength(100)]
        public string Titulo { get; set; }

        [StringLength(30)]
        public string Diretor { get; set; }

        public DateTime? DtLancamento { get; set; }

       [StringLength(50)]
        public string ImgFilme { get; set; }

        [StringLength(50)]
        public string Duracao { get; set; }

        [StringLength(20, ErrorMessage = "A classificação do filme não pode exceder 20 caracteres.")]
        public string Classificacao { get; set; }

        [StringLength(300, ErrorMessage = "A sinopse do filme não pode exceder 300 caracteres.")]
        public string Sinopse { get; set; }

        [Required]
        [StringLength(15)]
        public string Status { get; set; }

        public string Teste { get; set; }

        // Relacionamento 1-N com Reviews
        public ICollection<Review> Reviews { get; } = new List<Review>();

        //Relacionamento N:N com Genero
        public List<Genero> Generos { get; } = [];
    }
}
