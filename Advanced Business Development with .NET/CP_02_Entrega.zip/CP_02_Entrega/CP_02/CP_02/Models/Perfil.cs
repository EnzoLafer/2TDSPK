﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;

namespace CP_02.Models
{
    [Table("TB_PERFIL")]

    public class Perfil
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdPerfil { get; set; }

        [StringLength(100)]
        public string Imagem { get; set; }

        [StringLength(100)]
        public string Biografia { get; set; }

        // Relacionamento 1-1 com Usuario
        [Required]
        public int UsuarioIdUsuario { get; set; }
        public Usuario Usuario { get; set; } = null!;
    }
}
