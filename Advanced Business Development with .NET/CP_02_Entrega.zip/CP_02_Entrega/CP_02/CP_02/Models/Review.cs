﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;

namespace CP_02.Models
{
    [Table("TB_REVIEW")]

    public class Review
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdReview { get; set; }

        [Range(1, 5)]
        public int Avaliacao { get; set; }

        [StringLength(100)]
        public string Comentario { get; set; }

        public DateTime DtReview { get; set; }

        //Relacionamento 1:N com Filme
        [Required]
        public int FilmeIdFilme { get; set; }
        public Filme Filme { get; set; } = null!;

        //Relacionamento 1:N com Usuario
        [Required]
        public int UsuarioIdUsuario { get; set; }
        public Usuario Usuario { get; set; } = null!;

    }
}
