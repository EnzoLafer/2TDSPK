﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CP_02.Models
{
    [Table("TB_GENERO")]

    public class Genero
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdGenero { get; set; }

        [Required(ErrorMessage = "O gênero precisa ter um nome!")]
        [StringLength(20)]
        public string NomeGenero { get; set; }

        //Relacionamento N:N com Filme
        public List<Filme> Filmes { get; } = [];
    }
}
