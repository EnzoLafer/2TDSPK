﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CP_02.Migrations
{
    /// <inheritdoc />
    public partial class v3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TB_FILME_TB_GENERO_GeneroIdGenero",
                table: "TB_FILME");

            migrationBuilder.DropIndex(
                name: "IX_TB_FILME_GeneroIdGenero",
                table: "TB_FILME");

            migrationBuilder.DropColumn(
                name: "GeneroIdGenero",
                table: "TB_FILME");

            migrationBuilder.CreateTable(
                name: "FilmeGenero",
                columns: table => new
                {
                    FilmesIdFilme = table.Column<int>(type: "NUMBER(10)", nullable: false),
                    GenerosIdGenero = table.Column<int>(type: "NUMBER(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilmeGenero", x => new { x.FilmesIdFilme, x.GenerosIdGenero });
                    table.ForeignKey(
                        name: "FK_FilmeGenero_TB_FILME_FilmesIdFilme",
                        column: x => x.FilmesIdFilme,
                        principalTable: "TB_FILME",
                        principalColumn: "IdFilme",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FilmeGenero_TB_GENERO_GenerosIdGenero",
                        column: x => x.GenerosIdGenero,
                        principalTable: "TB_GENERO",
                        principalColumn: "IdGenero",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FilmeGenero_GenerosIdGenero",
                table: "FilmeGenero",
                column: "GenerosIdGenero");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FilmeGenero");

            migrationBuilder.AddColumn<int>(
                name: "GeneroIdGenero",
                table: "TB_FILME",
                type: "NUMBER(10)",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_TB_FILME_GeneroIdGenero",
                table: "TB_FILME",
                column: "GeneroIdGenero");

            migrationBuilder.AddForeignKey(
                name: "FK_TB_FILME_TB_GENERO_GeneroIdGenero",
                table: "TB_FILME",
                column: "GeneroIdGenero",
                principalTable: "TB_GENERO",
                principalColumn: "IdGenero",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
