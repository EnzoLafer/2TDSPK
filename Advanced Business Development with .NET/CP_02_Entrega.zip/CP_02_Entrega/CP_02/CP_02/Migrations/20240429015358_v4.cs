﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CP_02.Migrations
{
    /// <inheritdoc />
    public partial class v4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TB_PERFIL_TB_USUARIO_UsuarioId",
                table: "TB_PERFIL");

            migrationBuilder.DropForeignKey(
                name: "FK_TB_REVIEW_TB_FILME_FilmeId",
                table: "TB_REVIEW");

            migrationBuilder.DropForeignKey(
                name: "FK_TB_REVIEW_TB_USUARIO_UsuarioId",
                table: "TB_REVIEW");

            migrationBuilder.DropIndex(
                name: "IX_TB_REVIEW_FilmeId",
                table: "TB_REVIEW");

            migrationBuilder.DropIndex(
                name: "IX_TB_REVIEW_UsuarioId",
                table: "TB_REVIEW");

            migrationBuilder.DropIndex(
                name: "IX_TB_PERFIL_UsuarioId",
                table: "TB_PERFIL");

            migrationBuilder.DropColumn(
                name: "FilmeId",
                table: "TB_REVIEW");

            migrationBuilder.DropColumn(
                name: "UsuarioId",
                table: "TB_REVIEW");

            migrationBuilder.DropColumn(
                name: "UsuarioId",
                table: "TB_PERFIL");

            migrationBuilder.CreateIndex(
                name: "IX_TB_REVIEW_FilmeIdFilme",
                table: "TB_REVIEW",
                column: "FilmeIdFilme");

            migrationBuilder.CreateIndex(
                name: "IX_TB_REVIEW_UsuarioIdUsuario",
                table: "TB_REVIEW",
                column: "UsuarioIdUsuario");

            migrationBuilder.CreateIndex(
                name: "IX_TB_PERFIL_UsuarioIdUsuario",
                table: "TB_PERFIL",
                column: "UsuarioIdUsuario",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_TB_PERFIL_TB_USUARIO_UsuarioIdUsuario",
                table: "TB_PERFIL",
                column: "UsuarioIdUsuario",
                principalTable: "TB_USUARIO",
                principalColumn: "IdUsuario",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TB_REVIEW_TB_FILME_FilmeIdFilme",
                table: "TB_REVIEW",
                column: "FilmeIdFilme",
                principalTable: "TB_FILME",
                principalColumn: "IdFilme",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TB_REVIEW_TB_USUARIO_UsuarioIdUsuario",
                table: "TB_REVIEW",
                column: "UsuarioIdUsuario",
                principalTable: "TB_USUARIO",
                principalColumn: "IdUsuario",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TB_PERFIL_TB_USUARIO_UsuarioIdUsuario",
                table: "TB_PERFIL");

            migrationBuilder.DropForeignKey(
                name: "FK_TB_REVIEW_TB_FILME_FilmeIdFilme",
                table: "TB_REVIEW");

            migrationBuilder.DropForeignKey(
                name: "FK_TB_REVIEW_TB_USUARIO_UsuarioIdUsuario",
                table: "TB_REVIEW");

            migrationBuilder.DropIndex(
                name: "IX_TB_REVIEW_FilmeIdFilme",
                table: "TB_REVIEW");

            migrationBuilder.DropIndex(
                name: "IX_TB_REVIEW_UsuarioIdUsuario",
                table: "TB_REVIEW");

            migrationBuilder.DropIndex(
                name: "IX_TB_PERFIL_UsuarioIdUsuario",
                table: "TB_PERFIL");

            migrationBuilder.AddColumn<int>(
                name: "FilmeId",
                table: "TB_REVIEW",
                type: "NUMBER(10)",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UsuarioId",
                table: "TB_REVIEW",
                type: "NUMBER(10)",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UsuarioId",
                table: "TB_PERFIL",
                type: "NUMBER(10)",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_TB_REVIEW_FilmeId",
                table: "TB_REVIEW",
                column: "FilmeId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_REVIEW_UsuarioId",
                table: "TB_REVIEW",
                column: "UsuarioId");

            migrationBuilder.CreateIndex(
                name: "IX_TB_PERFIL_UsuarioId",
                table: "TB_PERFIL",
                column: "UsuarioId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_TB_PERFIL_TB_USUARIO_UsuarioId",
                table: "TB_PERFIL",
                column: "UsuarioId",
                principalTable: "TB_USUARIO",
                principalColumn: "IdUsuario",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TB_REVIEW_TB_FILME_FilmeId",
                table: "TB_REVIEW",
                column: "FilmeId",
                principalTable: "TB_FILME",
                principalColumn: "IdFilme",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_TB_REVIEW_TB_USUARIO_UsuarioId",
                table: "TB_REVIEW",
                column: "UsuarioId",
                principalTable: "TB_USUARIO",
                principalColumn: "IdUsuario",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
