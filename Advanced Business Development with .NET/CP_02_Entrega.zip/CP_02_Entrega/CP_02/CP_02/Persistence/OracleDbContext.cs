﻿using CP_02.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

namespace CP_02.Persistence
{
    public class OracleDbContext : DbContext
    {
        //Mapeamento das classes
        public DbSet<Filme> Filme { get; set; }
        public DbSet<Genero> Genero { get; set; }
        public DbSet<Perfil> Perfil { get; set; }
        public DbSet<Review> Review { get; set; }
        public DbSet<Usuario> Usuario { get; set; }

        //Construtor
        public OracleDbContext(DbContextOptions<OracleDbContext> options) : base(options)
        {


        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Genero>()
                .HasMany(e => e.Filmes)
                .WithMany(e => e.Generos);
        }
    }
}
