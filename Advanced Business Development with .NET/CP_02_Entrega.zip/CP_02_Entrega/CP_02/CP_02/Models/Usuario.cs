﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Metadata;

namespace CP_02.Models
{
    [Table("TB_USUARIO")]

    public class Usuario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdUsuario { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório.")]
        [StringLength(50)]
        public string NomeUsuario { get; set; }

        [StringLength(50, ErrorMessage = "O seu sobrenome só pode conter 50 caracteres.")]
        public string SobrenomeUsuario { get; set; }

        [Required]
        [StringLength(100)]
        [EmailAddress(ErrorMessage = "O e-mail informado é inválido.")]
        public string DsEmail { get; set; }

        [Required]
        [StringLength(20, MinimumLength = 8, ErrorMessage = "A senha deve conter entre 8 e 20 caracteres.")]
        public string DsSenha { get; set; }

        // Relacionamento 1-N com Reviews
        public ICollection<Review> Reviews { get; } = new List<Review>();

        // Relacionamento 1-1 com Perfil
        public Perfil? Perfil { get; set; }
    }
}
